module.exports = {
  title: 'Trojan Panel',
  showSettings: false,
  tagsView: true,
  fixedHeader: true,
  sidebarLogo: true
}
